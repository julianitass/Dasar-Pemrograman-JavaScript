import { test } from 'node:test';
import assert from 'node:assert';
import sum from './index.js';

// Uji skenario 1: Penjumlahan dua bilangan positif
test('sum(3, 5) should return 8', () => {
  const result = sum(3, 5);
  assert.strictEqual(result, 8);
});

// Uji skenario 2: Salah satu atau kedua input adalah bilangan negatif
test('sum(-1, 5) should return 0', () => {
  const result = sum(-1, 5);
  assert.strictEqual(result, 0);
});

test('sum(4, -3) should return 0', () => {
  const result = sum(4, -3);
  assert.strictEqual(result, 0);
});

test('sum(-2, -3) should return 0', () => {
  const result = sum(-2, -3);
  assert.strictEqual(result, 0);
});

// Uji skenario 3: Input bukan bilangan
test('sum("3", 5) should return 0', () => {
  const result = sum("3", 5);
  assert.strictEqual(result, 0);
});

test('sum(4, "5") should return 0', () => {
  const result = sum(4, "5");
  assert.strictEqual(result, 0);
});

test('sum(true, 5) should return 0', () => {
  const result = sum(true, 5);
  assert.strictEqual(result, 0);
});

test('sum(4, null) should return 0', () => {
  const result = sum(4, null);
  assert.strictEqual(result, 0);
});

// Uji skenario 4: Input adalah 0
test('sum(0, 0) should return 0', () => {
  const result = sum(0, 0);
  assert.strictEqual(result, 0);
});

test('sum(0, 5) should return 5', () => {
  const result = sum(0, 5);
  assert.strictEqual(result, 5);
});

test('sum(4, 0) should return 4', () => {
  const result = sum(4, 0);
  assert.strictEqual(result, 4);
});
