import { test } from 'node:test';
import assert from 'node:assert';
import { sum } from './index.js';

// Uji kasus 1: Penjumlahan dua bilangan positif
test('sum(2, 3) should return 5', () => {
  const result = sum(2, 3);
  assert.strictEqual(result, 5);
});

// Uji kasus 2: Penjumlahan dua bilangan negatif
test('sum(-1, -2) should return -3', () => {
  const result = sum(-1, -2);
  assert.strictEqual(result, -3);
});

// Uji kasus 3: Penjumlahan bilangan positif dan negatif
test('sum(5, -3) should return 2', () => {
  const result = sum(5, -3);
  assert.strictEqual(result, 2);
});

// Uji kasus 4: Penjumlahan dengan nol
test('sum(0, 5) should return 5', () => {
  const result = sum(0, 5);
  assert.strictEqual(result, 5);
});
