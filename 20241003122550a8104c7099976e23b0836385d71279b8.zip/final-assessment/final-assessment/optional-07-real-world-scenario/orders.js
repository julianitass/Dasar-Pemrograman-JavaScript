// Array untuk menyimpan semua pesanan
let orders = [];

// Fungsi untuk menghasilkan ID unik
function generateId() {
  return '_' + Math.random().toString(36).substr(2, 9);
}

// Fungsi untuk menambahkan pesanan baru
function addOrder(customerName, items) {
  const totalPrice = items.reduce((total, item) => total + item.price, 0);
  const newOrder = {
    id: generateId(),
    customerName: customerName,
    items: items,
    totalPrice: totalPrice,
    status: 'Menunggu'
  };
  orders.push(newOrder);
}

// Fungsi untuk memperbarui status pesanan
function updateOrderStatus(orderId, newStatus) {
  const order = orders.find(order => order.id === orderId);
  if (order) {
    order.status = newStatus;
  } else {
    console.log(`Pesanan dengan ID ${orderId} tidak ditemukan.`);
  }
}

// Fungsi untuk menghitung total pendapatan dari pesanan yang sudah selesai
function calculateTotalRevenue() {
  return orders
    .filter(order => order.status === 'Selesai')
    .reduce((total, order) => total + order.totalPrice, 0);
}

// Fungsi untuk menghapus pesanan berdasarkan ID
function deleteOrder(orderId) {
  orders = orders.filter(order => order.id !== orderId);
}

export { orders, addOrder, updateOrderStatus, calculateTotalRevenue, deleteOrder };
